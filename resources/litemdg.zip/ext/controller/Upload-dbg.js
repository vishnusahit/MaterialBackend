sap.ui.define(
    ["sap/m/MessageBox", "sap/m/MessageToast", "litemdg/ext/lib/xlsx","litemdg/ext/lib/jszip"],
    function (MessageBox, MessageToast, xlsxjs) {
        "use strict";
        var oControl;
        function _createUploadController(oExtensionAPI, Entity) {
            var oUploadDialog;
            // const xlsx = sap.ui.require('xlsx');

            function setOkButtonEnabled(bOk) {
                oUploadDialog && oUploadDialog.getBeginButton().setEnabled(bOk);
            }

            function setDialogBusy(bBusy) {
                oUploadDialog.setBusy(bBusy)
            }

            function closeDialog() {
                oUploadDialog && oUploadDialog.close()
            }

            function showError(sMessage) {
                MessageBox.error(sMessage || "Upload failed")
            }

            // TODO: Better option for this?
            function byId(sId) {
                // return sap.ui.core.Fragment.byId("uploadDialog", sId);
                return sap.ui.core.Fragment.byId("idUploadDialog", sId);
            }

            function upload(jsonData) {

                // var sUrl = "../odata/v4/litemdg-srv/Material.drafts";  // Set your CAPM service URL here

                // $.ajax({
                //     url: sUrl,
                //     type: "POST",
                //     contentType: "application/json",
                //     data: JSON.stringify(jsonData),  // Convert the JSON data to a string
                //     success: function (response) {
                //         MessageToast.show("Students uploaded successfully!");
                //         setDialogBusy(false);  // Stop the busy indicator
                //         closeDialog();
                //         oExtensionAPI.refresh();  // Refresh the data if needed
                //     },
                //     error: function (jqXHR, textStatus, errorThrown) {
                //         showError("Upload failed: " + textStatus + " - " + errorThrown);
                //         setDialogBusy(false);  // Stop the busy indicator
                //     }
                // });

                //var oView = sap.ui.core.Fragment.byId("uploadDialog").getParent(); 

                var oModel = oExtensionAPI.getOwnerComponent().getModel("odataV2");
                var aPromises = [];

                jsonData.forEach(function (studentData) {
                    aPromises.push(new Promise(function (resolve, reject) {
                        // oModel.create("/Material", studentData, {
                        oModel.create("/Rules", studentData, {    
                            success: function (oData) {
                                resolve(oData);
                            },
                            error: function (oError) {
                                reject(oError);
                            }
                        });
                    }));
                });

                Promise.all(aPromises)
                    .then(function (results) {
                        MessageToast.show("All students uploaded successfully!");
                        setDialogBusy(false);
                        closeDialog();
                        oExtensionAPI.refresh(); // Refresh the data
                    })
                    .catch(function (error) {
                        showError("Upload failed: " + error.message);
                        setDialogBusy(false);
                    });

            }

            return {
                onBeforeOpen: function (oEvent) {
                    oUploadDialog = oEvent.getSource();
                    oExtensionAPI.addDependent(oUploadDialog);
                },

                onAfterClose: function (oEvent) {
                    oExtensionAPI.removeDependent(oUploadDialog);
                    oUploadDialog.destroy();
                    oUploadDialog = undefined;
                },

                onOk: function (oEvent) {
                    setDialogBusy(true)
                    var that = this;
                    var oFileUploader = byId("uploader");
                    // var headPar = new sap.ui.unified.FileUploaderParameter();
                    // headPar.setName('slug');
                    // headPar.setValue(Entity);
                    // oFileUploader.removeHeaderParameter('slug');
                    // oFileUploader.addHeaderParameter(headPar);
                    // var sUploadUri = oExtensionAPI._controller.extensionAPI._controller._oAppComponent.getManifestObject().resolveUri("./litemdg_srv/ExcelUpload/excel")
                    // oFileUploader.setUploadUrl(sUploadUri);
                    // oFileUploader
                    //     .checkFileReadable()
                    //     .then(function () {
                    //         oFileUploader.upload();
                    //     })
                    //     .catch(function (error) {
                    //         showError("The file cannot be read.");
                    //         setDialogBusy(false)
                    //     })

                    var oFile = oFileUploader.oFileUpload.files[0];

                    if (!oFile) {
                        MessageToast.show("Please select an Excel file.");
                        return;
                    }


                    var reader = new FileReader();
                    reader.onload = (event) => {
                        var data = event.target.result;

                        var workbook = XLSX.read(data, { type: "binary" });

                        var sheetName = workbook.SheetNames[0];
                        var sheet = workbook.Sheets[sheetName];

                        // Convert Excel to JSON
                        var jsonData = XLSX.utils.sheet_to_json(sheet);

                        // Send data to backend service
                        // upload(jsonData).bind(oControl);

                        var oModel = oExtensionAPI.getModel("odataV2");
                        var aPromises = [];

                        jsonData.forEach(function (studentData) {
                            aPromises.push(new Promise(function (resolve, reject) {
                                oModel.create("/Material", studentData, {
                                    success: function (oData) {
                                        //console.log("Success:", oData); 
                                        resolve(oData);
                                    },
                                    error: function (oError) {
                                        console.log("fail:", oError); 
                                        reject(oError);
                                    }
                                });
                            }));
                        });

                        Promise.all(aPromises)
                            .then(function (results) {
                                //MessageToast.show("All students uploaded successfully!");
                                closeDialog();
                                oExtensionAPI.refresh(); // Refresh the data
                                oModel.submitChanges({
                                    success: function () {
                                        MessageToast.show("Uploaded successfully!");
                                         // Refresh model to display latest data
                                      
                                        oModel.refresh(true);
                                       
                                        closeDialog();
                                    },
                                    error: function (oError) {
                                        showError("Failed to save changes: " + oError.message);
                                        setDialogBusy(false);
                                    }
                                });
                            })
                            .catch(function (error) {
                                showError("Upload failed: " + error.message);
                                setDialogBusy(false);
                            });


                    };

                    reader.onerror = (error) => {
                        MessageToast.show("Error reading file: " + error);
                    };

                    reader.readAsBinaryString(oFile);


                },

                onCancel: function (oEvent) {
                    closeDialog();
                },

                onTypeMismatch: function (oEvent) {
                    var sSupportedFileTypes = oEvent
                        .getSource()
                        .getFileType()
                        .map(function (sFileType) {
                            return "*." + sFileType;
                        })
                        .join(", ");

                    showError(
                        "The file type *." +
                        oEvent.getParameter("fileType") +
                        " is not supported. Choose one of the following types: " +
                        sSupportedFileTypes
                    );
                },

                onFileAllowed: function (oEvent) {
                    setOkButtonEnabled(true)
                },

                onFileEmpty: function (oEvent) {
                    setOkButtonEnabled(false)
                },

                onUploadComplete: function (oEvent) {
                    var iStatus = oEvent.getParameter("status");
                    var oFileUploader = oEvent.getSource()

                    oFileUploader.clear();
                    setOkButtonEnabled(false)
                    setDialogBusy(false)

                    if (iStatus >= 400) {
                        var oRawResponse = JSON.parse(oEvent.getParameter("responseRaw"));
                        showError(oRawResponse && oRawResponse.error && oRawResponse.error.message);
                    } else {
                        MessageToast.show("Uploaded successfully");
                        oExtensionAPI.refresh()
                        closeDialog();
                    }
                }
            };
        }

        return {

            onClick: function (oBindingContext, aSelectedContexts) {
                oControl = this;
                this.loadFragment({
                    // id: "uploadDialog",
                    id:"idUploadDialog",
                    name: "litemdg.ext.fragments.uploadDialog",
                    controller: _createUploadController(this, 'Rules')

                }).then(function (oDialog) {
                    oDialog.open();
                });
            }
        };
    }
);