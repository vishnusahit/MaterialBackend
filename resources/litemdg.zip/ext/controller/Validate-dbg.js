sap.ui.define([
    "sap/m/MessageToast",
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
], function(MessageToast,Controller,JSONModel) {
    'use strict';
    var oParameters;
    function _createUploadController(oExtensionAPI){
        var oUploadDialog;
        function closeDialog() {
            oUploadDialog && oUploadDialog.close()
        }

     return {
        onBeforeOpen: function (oEvent) {
            oUploadDialog = oEvent.getSource();
            oExtensionAPI.addDependent(oUploadDialog);
        },

        onAfterClose: function (oEvent) {
            oExtensionAPI.removeDependent(oUploadDialog);
            oUploadDialog.destroy();
            oUploadDialog = undefined;
        },
        onCancel: function (oEvent) {
            closeDialog();
        }
     }
    }
    var oView = sap.ui.getCore().byId("uploadDialog");

    return {
        onValidate: function(oEvent) {
            MessageToast.show("Custom handler invoked.");
            //var oView = this.getView();
            //oView = this.getRouting().getView();
            var oModel = new JSONModel();
            var sUrl = "https://py_mdg_duplicate_chk.cfapps.us10-001.hana.ondemand.com/result";
            $.ajax({
                url: sUrl,
                method: "GET",
                dataType: "json",
                contentType: 'application/json',
                data: oParameters,
                success: function (oData) {
                    // Hide busy indicator
                    sap.ui.core.BusyIndicator.hide();
                    // Set the data to the model
                    console.log("Data received: ", oData);
                    oModel.setData(oData);
                    //sap.ui.getCore().byId("uploadDialog").setModel(oModel, "duplicatesModel");
                    // Optionally show a success message
                    MessageToast.show("Data loaded successfully.");
                },
                error: function (oError) {
                    // Hide busy indicator
                    sap.ui.core.BusyIndicator.hide();

                    // Optionally show an error message
                    MessageToast.show("Failed to load data from the Python service.");
                }
            });
        
            this.loadFragment({
                id: "uploadDialog",
                name: "litemdg.ext.fragments.duplicate",
                controller: _createUploadController(this)
                
            }).then(function (oDialog) {
                oDialog.setModel(oModel, "duplicatesModel");
                oDialog.open();
            });

            
        },
      
    };
});
