sap.ui.define(["sap/m/MessageToast"],function(n){"use strict";return{onClick:function(s){n.show("Custom handler invoked.")}}});
//# sourceMappingURL=Click.js.map